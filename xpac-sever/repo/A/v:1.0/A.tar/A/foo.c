#include <stdio.h>

int main() {
	printf("Hello World: A");
	return 0;
}
