#include<stdio.h>

/*-----------------------------------------|
| Prints a cow to the terminal	           |
| Author: Utkarsh Jain (utkjain@gmail.com) |
--------------------------------------------*/

/*------------------------------- command to run : utkycow -------------------------------*/

int main () {
	//print the cow
	printf("\n");
        printf("               _____________________________________ \n");  
        printf("              |                                     |\n");
        printf("              | xpac is an awesome package manager! |\n");
        printf("              |_____________________________________|\n");
        printf("              /\n");
        printf("             / \n");
        printf("         (__)\n");
	printf("         (oo)\n");
	printf("  /-------\\/ \n");
	printf(" / |     || \n");
	printf("+  ||----|| \n");
	printf("   ~~    ~~ \n");
        printf("\n");       

        return 0;
}
